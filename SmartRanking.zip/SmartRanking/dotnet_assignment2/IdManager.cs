﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotnet_assignment2
{
    public class IdManager
    {
        private static IdManager _instance = null;
        private static readonly string _filePath = Utils.ID_LIST;
        private readonly Random _random = new Random();

        private IdManager()
        {
            if (!File.Exists(_filePath))
            {
                File.Create(_filePath).Close();
            }
        }

        public static IdManager GetInstance()
        {
            if (_instance == null)
            {
                _instance = new IdManager();
            }

            return _instance;
        }

        public int GenerateUniqueId()
        {
            int id;
            do
            {
                id = _random.Next(10000, 100000000); // 5 to 8 digits
            } while (IdExists(id));

            AddId(id);
            return id;
        }

        public void AddId(int id)
        {
            if (!IdExists(id))
            {
                using (StreamWriter sw = File.AppendText(_filePath))
                {
                    sw.WriteLine(id);
                }
            }
        }

        public bool IdExists(int id)
        {
            using (StreamReader sr = new StreamReader(_filePath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    int existingId;
                    if (int.TryParse(line, out existingId))
                    {
                        if (existingId == id)
                            return true;
                    }
                }
            }

            return false;
        }
    }
}