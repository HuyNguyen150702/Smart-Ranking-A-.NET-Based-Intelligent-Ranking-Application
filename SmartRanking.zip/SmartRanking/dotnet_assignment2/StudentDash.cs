﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace dotnet_assignment2
{
    public partial class StudentDash : Form
    {
        private readonly string _studentName;

        private readonly string _awardsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "awards.txt");
        private readonly string _competitionsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "competitions.txt");
        private readonly string _postsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "posts.txt");
        private readonly string _leaderboardPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "leaderboard.txt");
        private readonly string _feedbackPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "feedback.txt");

        // includes 'competition' (older rows without it will deserialize with null)
        private record Award(string competition, string title, string student, string description, DateTime createdAt);
        private record Competition(string name, string rules, DateTime createdAt);
        private record Post(string title, string content, DateTime createdAt);
        private record LeaderboardEntry(string competition, string student, int score, DateTime createdAt);
        private record FeedbackEntry(string competition, string student, string teacher, string feedback, DateTime createdAt);

        private List<Award> _awardsCache = new();
        private List<Competition> _compsCache = new();

        private FileSystemWatcher _lbWatcher;
        private FileSystemWatcher _fbWatcher;

        public StudentDash() : this("Student") { }
        public StudentDash(string studentName)
        {
            InitializeComponent();
            _studentName = string.IsNullOrWhiteSpace(studentName) ? "Student" : studentName;
            lblWelcome.Text = $"Welcome, {_studentName}!";

            EnsureFiles();
            LoadAllDataIntoUI();
            SetupWatchers();
        }

        private static string N(string s) => (s ?? "").Trim();

        private void EnsureFiles()
        {
            var dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");
            Directory.CreateDirectory(dir);
            Touch(_awardsPath);
            Touch(_competitionsPath);
            Touch(_postsPath);
            Touch(_leaderboardPath);
            Touch(_feedbackPath);
        }
        private static void Touch(string p) { if (!File.Exists(p)) File.Create(p).Dispose(); }

        private static List<T> LoadJsonl<T>(string path)
        {
            var list = new List<T>();
            if (!File.Exists(path)) return list;
            foreach (var line in File.ReadLines(path))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                try { var obj = JsonSerializer.Deserialize<T>(line); if (obj != null) list.Add(obj); } catch { }
            }
            return list;
        }

        private void LoadAllDataIntoUI()
        {
            _compsCache = LoadJsonl<Competition>(_competitionsPath)
                         .OrderByDescending(c => c.createdAt).ToList();

            listCompetitions.Items.Clear();
            foreach (var c in _compsCache) listCompetitions.Items.Add(c.name);
            if (listCompetitions.Items.Count > 0 && listCompetitions.SelectedIndex < 0)
                listCompetitions.SelectedIndex = 0;

            _awardsCache = LoadJsonl<Award>(_awardsPath)
                          .OrderByDescending(a => a.createdAt).ToList();

            listAwards.Items.Clear();
            foreach (var a in _awardsCache)
            {
                var comp = string.IsNullOrWhiteSpace(a.competition) ? "(no contest)" : a.competition;
                listAwards.Items.Add($"[{comp}] {a.title} — {a.student} — {a.description}");
            }

            var posts = LoadJsonl<Post>(_postsPath).OrderByDescending(p => p.createdAt).ToList();
            txtPosts.Clear();
            txtPosts.Text = posts.Any()
                ? string.Join(Environment.NewLine + Environment.NewLine,
                    posts.Select(p => $"{p.title} ({p.createdAt:yyyy-MM-dd HH:mm}){Environment.NewLine}{p.content}"))
                : "No announcements/posts yet.";

            txtDetail.Text = "Select a competition to view rules and leaderboard.";
            txtFeedback.Text = string.Empty;
            txtLeaderboard.Clear();
        }

        private void SetupWatchers()
        {
            var dir = Path.GetDirectoryName(_leaderboardPath)!;

            _lbWatcher = new FileSystemWatcher(dir)
            {
                Filter = Path.GetFileName(_leaderboardPath),
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size
            };
            _lbWatcher.Changed += (_, __) => SafeRefreshSelected();
            _lbWatcher.EnableRaisingEvents = true;

            _fbWatcher = new FileSystemWatcher(dir)
            {
                Filter = Path.GetFileName(_feedbackPath),
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size
            };
            _fbWatcher.Changed += (_, __) => SafeRefreshSelected();
            _fbWatcher.EnableRaisingEvents = true;
        }

        private void SafeRefreshSelected()
        {
            if (!IsHandleCreated) return;
            try
            {
                BeginInvoke((Action)(() =>
                {
                    if (listCompetitions.SelectedIndex >= 0)
                        listCompetitions_SelectedIndexChanged(this, EventArgs.Empty);
                }));
            }
            catch { }
        }

        private void listCompetitions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listCompetitions.SelectedIndex < 0 || listCompetitions.SelectedIndex >= _compsCache.Count) return;

            var comp = _compsCache[listCompetitions.SelectedIndex];
            var compName = N(comp.name);

            // auto-switch so scores are visible
            tabDetails.SelectedTab = tabLeaderboard;

            txtDetail.Text = $"Competition: {comp.name}{Environment.NewLine}{Environment.NewLine}Rules:{Environment.NewLine}{comp.rules}";

            var entries = LoadJsonl<LeaderboardEntry>(_leaderboardPath)
                         .Where(le => string.Equals(N(le.competition), compName, StringComparison.OrdinalIgnoreCase))
                         .OrderByDescending(le => le.score).ToList();

            if (entries.Any())
            {
                var lines = entries.Select((le, i) => $"{i + 1}. {le.student} — {le.score}").ToList();
                var myIndex = entries.FindIndex(le => string.Equals(N(le.student), N(_studentName), StringComparison.OrdinalIgnoreCase));
                if (myIndex >= 0)
                {
                    var myEntry = entries[myIndex];
                    lines.Add(string.Empty);
                    lines.Add($"Your grade: {myEntry.score} (rank #{myIndex + 1})");
                }
                else
                {
                    lines.Add(string.Empty);
                    lines.Add("You have not been graded yet.");
                }
                txtLeaderboard.Text = $"Leaderboard — {compName}{Environment.NewLine}{string.Join(Environment.NewLine, lines)}";
            }
            else
            {
                txtLeaderboard.Text = $"No leaderboard entries yet for {compName}.";
            }

            var feedbacks = LoadJsonl<FeedbackEntry>(_feedbackPath)
                           .Where(f => string.Equals(N(f.competition), compName, StringComparison.OrdinalIgnoreCase)
                                    && string.Equals(N(f.student), N(_studentName), StringComparison.OrdinalIgnoreCase))
                           .OrderByDescending(f => f.createdAt).ToList();

            // include contest tag in each line (you asked for this)
            txtFeedback.Text = feedbacks.Any()
                ? string.Join(Environment.NewLine + Environment.NewLine,
                    feedbacks.Select(f => $"[{f.competition}] From {f.teacher} ({f.createdAt:yyyy-MM-dd HH:mm}):{Environment.NewLine}{f.feedback}"))
                : $"No feedback yet for this competition ({compName}).";
        }

        private void listAwards_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = listAwards.SelectedIndex;
            if (idx < 0 || idx >= _awardsCache.Count) return;

            var a = _awardsCache[idx];
            var comp = string.IsNullOrWhiteSpace(a.competition) ? "(no contest)" : a.competition;

            MessageBox.Show(
                $"Competition: {comp}{Environment.NewLine}" +
                $"Student    : {a.student}{Environment.NewLine}" +
                $"Title      : {a.title}{Environment.NewLine}" +
                $"Date       : {a.createdAt:yyyy-MM-dd HH:mm}{Environment.NewLine}{Environment.NewLine}" +
                $"Description:{Environment.NewLine}{a.description}",
                "Award Details",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog
            {
                Title = "Upload Assignment / Blog",
                Filter = "PDF Files|*.pdf|Word Documents|*.docx|All Files|*.*"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            MessageBox.Show($"File '{dlg.FileName}' submitted successfully!", "Submission",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtFeedback.Text = "Teacher will review your submission soon.";
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAllDataIntoUI();
            if (listCompetitions.SelectedIndex >= 0)
                listCompetitions_SelectedIndexChanged(this, EventArgs.Empty);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            _lbWatcher?.Dispose();
            _fbWatcher?.Dispose();

            var login = new LogIn();
            login.StartPosition = FormStartPosition.CenterScreen;
            login.Show();
            Close();
        }

        private void txtDetail_TextChanged(object sender, EventArgs e) { }
        private void txtPosts_TextChanged(object sender, EventArgs e) { }
        private void txtFeedback_TextChanged(object sender, EventArgs e) { }
    }
}
