﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace dotnet_assignment2
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();

            // Make sure password masking + event are reliable at runtime
            TxtPassword.UseSystemPasswordChar = true;
            TxtPassword.Multiline = false;

            TxtConfirmed.UseSystemPasswordChar = true;
            TxtConfirmed.Multiline = false;

            checkBox1.CheckedChanged -= checkBox1_CheckedChanged;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
        }

        // REGISTER button
        private void button1_Click(object sender, EventArgs e)
        {
            string username = TxtUsername.Text.Trim();
            string password = TxtPassword.Text.Trim();
            string confirmed = TxtConfirmed.Text.Trim();

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("Please enter a username.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtUsername.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(confirmed))
            {
                MessageBox.Show("Please enter and confirm your password.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (password != confirmed)
            {
                MessageBox.Show("Passwords do not match.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check duplicate (students)
            var students = FileManager.LoadEntities<Student>(Utils.STUDENT);
            bool exists = students.Any(s => s.firstName.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (exists)
            {
                MessageBox.Show("Username already exists. Please choose another.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtUsername.Focus();
                return;
            }

            // Create student
            int id = IdManager.GetInstance().GenerateUniqueId();
            var student = new Student(
                id,
                password,
                username,               // firstName used as username per your BaseEntity
                "",
                $"{username}@mail.com",
                "0000000000",
                "Unknown"
            );

            FileManager.SaveEntity(student, Utils.STUDENT);

            MessageBox.Show("Registration successful! You can now log in.", "Success",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            var login = new LogIn();
            login.Show();
            this.Hide();
        }

        // CLEAR button
        private void btnClear_Click(object sender, EventArgs e)
        {
            TxtUsername.Clear();
            TxtPassword.Clear();
            TxtConfirmed.Clear();
            TxtUsername.Focus();
        }

        // Back to Log In (label6)
        private void label6_Click(object sender, EventArgs e)
        {
            var login = new LogIn();
            login.Show();
            this.Hide();
        }

        // Show Passwords
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            bool show = checkBox1.Checked;
            TxtPassword.UseSystemPasswordChar = !show;
            TxtConfirmed.UseSystemPasswordChar = !show;
        }

        // stubs for designer-wired events (if any)
        private void label1_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
    }
}
