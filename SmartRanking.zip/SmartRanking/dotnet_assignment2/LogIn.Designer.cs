﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace dotnet_assignment2
{
    partial class LogIn
    {
        private System.ComponentModel.IContainer components = null;

        // Designer fields
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox3;
        private Label label3;
        private Button button1;
        private Label label4;
        private Label label5;
        private TextBox TxtUsername;
        private TextBox TxtPassword;

        // NEW: Register link
        private Label label7;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogIn));
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            button1 = new Button();
            label4 = new Label();
            label5 = new Label();
            TxtUsername = new TextBox();
            TxtPassword = new TextBox();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(116, 11);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(235, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bauhaus 93", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(104, 136);
            label1.Name = "label1";
            label1.Size = new Size(265, 21);
            label1.TabIndex = 1;
            label1.Text = "Welcome To Smart Ranking";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 8.25F);
            label2.Location = new Point(89, 176);
            label2.Name = "label2";
            label2.Size = new Size(58, 13);
            label2.TabIndex = 2;
            label2.Text = "Username:";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(62, 169);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(19, 20);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 117, 224);
            panel1.ForeColor = Color.Blue;
            panel1.Location = new Point(115, 224);
            panel1.Name = "panel1";
            panel1.Size = new Size(236, 1);
            panel1.TabIndex = 4;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(0, 117, 224);
            panel2.Location = new Point(116, 296);
            panel2.Name = "panel2";
            panel2.Size = new Size(236, 1);
            panel2.TabIndex = 5;
            panel2.Paint += panel2_Paint;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(62, 238);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(19, 24);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 8.25F);
            label3.Location = new Point(89, 249);
            label3.Name = "label3";
            label3.Size = new Size(56, 13);
            label3.TabIndex = 7;
            label3.Text = "Password:";
            label3.Click += label3_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Bahnschrift", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(143, 349);
            button1.Name = "button1";
            button1.Size = new Size(171, 33);
            button1.TabIndex = 8;
            button1.Text = "LOG IN";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(310, 320);
            label4.Name = "label4";
            label4.Size = new Size(91, 16);
            label4.TabIndex = 9;
            label4.Text = "Clear Fields";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(212, 431);
            label5.Name = "label5";
            label5.Size = new Size(32, 16);
            label5.TabIndex = 10;
            label5.Text = "Exit";
            label5.Click += label5_Click;
            // 
            // TxtUsername
            // 
            TxtUsername.BorderStyle = BorderStyle.None;
            TxtUsername.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TxtUsername.ForeColor = Color.FromArgb(0, 117, 214);
            TxtUsername.Location = new Point(116, 196);
            TxtUsername.Multiline = true;
            TxtUsername.Name = "TxtUsername";
            TxtUsername.Size = new Size(236, 24);
            TxtUsername.TabIndex = 11;
            TxtUsername.TextChanged += TxtUsername_TextChanged;
            // 
            // TxtPassword
            // 
            TxtPassword.BorderStyle = BorderStyle.None;
            TxtPassword.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TxtPassword.ForeColor = Color.FromArgb(0, 117, 214);
            TxtPassword.Location = new Point(116, 270);
            TxtPassword.Multiline = true;
            TxtPassword.Name = "TxtPassword";
            TxtPassword.Size = new Size(236, 24);
            TxtPassword.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.DodgerBlue;
            label7.Location = new Point(173, 399);
            label7.Name = "label7";
            label7.Size = new Size(112, 16);
            label7.TabIndex = 13;
            label7.Text = "Create Account";
            label7.Click += label7_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 14F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(456, 643);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Controls.Add(pictureBox3);
            Controls.Add(label3);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(TxtUsername);
            Controls.Add(TxtPassword);
            Controls.Add(label7);
            Font = new Font("Bauhaus 93", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = Color.FromArgb(0, 117, 224);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Login";
            Load += LogIn_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
    }
}
