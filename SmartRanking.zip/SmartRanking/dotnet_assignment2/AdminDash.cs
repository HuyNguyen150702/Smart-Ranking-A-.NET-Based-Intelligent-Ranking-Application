﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace dotnet_assignment2
{
    public partial class Form5 : Form
    {
        // ------- Local data files for admin features -------
        private readonly string _dataDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");
        private readonly string _awardsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "awards.txt");
        private readonly string _competitionsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "competitions.txt");
        private readonly string _postsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "posts.txt");
        private readonly string _leaderboardPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "leaderboard.txt");
        private readonly string _logsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "logs.txt");

        public Form5()
        {
            InitializeComponent();

            // Ensure extra data files exist
            Directory.CreateDirectory(_dataDir);
            Touch(_awardsPath);
            Touch(_competitionsPath);
            Touch(_postsPath);
            Touch(_leaderboardPath);
            Touch(_logsPath);

            Log("AdminDash opened.");
        }

        // -------------------- MODELS (lightweight) --------------------
        private record Award(string title, string student, string description, DateTime createdAt);
        private record Competition(string name, string rules, DateTime createdAt);
        private record Post(string title, string content, DateTime createdAt);
        private record LeaderboardEntry(string competition, string student, int score, DateTime createdAt);

        // -------------------- UTILITIES --------------------
        private static void Touch(string path)
        {
            if (!File.Exists(path)) File.Create(path).Dispose();
        }

        private static List<T> LoadJsonl<T>(string path)
        {
            var list = new List<T>();
            if (!File.Exists(path)) return list;
            foreach (var line in File.ReadLines(path))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                try
                {
                    var obj = JsonSerializer.Deserialize<T>(line);
                    if (obj != null) list.Add(obj);
                }
                catch { /* skip bad lines */ }
            }
            return list;
        }

        private static void SaveJsonlOverwrite<T>(string path, IEnumerable<T> items)
        {
            var lines = items.Select(i => JsonSerializer.Serialize(i));
            File.WriteAllLines(path, lines);
        }

        private static void AppendJsonl<T>(string path, T item)
        {
            File.AppendAllText(path, JsonSerializer.Serialize(item) + Environment.NewLine);
        }

        private void Log(string msg)
        {
            var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {msg}";
            File.AppendAllText(_logsPath, line + Environment.NewLine);
        }

        // Re-usable prompt dialog
        private static string? Prompt(string title, string question, string defaultValue = "")
        {
            using var f = new Form
            {
                Width = 460,
                Height = 170,
                Text = title,
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false
            };
            var lbl = new Label { Left = 12, Top = 15, Width = 420, Text = question };
            var txt = new TextBox { Left = 12, Top = 40, Width = 420, Text = defaultValue };
            var ok = new Button { Text = "OK", Left = 266, Width = 80, Top = 80, DialogResult = DialogResult.OK };
            var cancel = new Button { Text = "Cancel", Left = 352, Width = 80, Top = 80, DialogResult = DialogResult.Cancel };
            f.Controls.Add(lbl); f.Controls.Add(txt); f.Controls.Add(ok); f.Controls.Add(cancel);
            f.AcceptButton = ok; f.CancelButton = cancel;
            return f.ShowDialog() == DialogResult.OK ? txt.Text : null;
        }

        // -------------------- MANAGE USERS --------------------
        // Wire this to btnManageUsers.Click
        private void btnManageUsers_Click(object sender, EventArgs e)
        {
            // Simple action picker
            var action = Prompt("Manage Users", "Type action: create, edit, delete, assignrole");
            if (action == null) return;

            switch (action.Trim().ToLowerInvariant())
            {
                case "create":
                    CreateUser();
                    break;
                case "edit":
                    EditUserPassword();
                    break;
                case "delete":
                    DeleteUser();
                    break;
                case "assignrole":
                    AssignRole();
                    break;
                default:
                    MessageBox.Show("Unknown action. Use: create, edit, delete, assignrole",
                        "Manage Users", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
        }

        private void CreateUser()
        {
            var role = Prompt("Create User", "Enter role (student/teacher/admin):", "student");
            if (role == null) return;

            var username = Prompt("Create User", "Enter username (stored in firstName):");
            if (string.IsNullOrWhiteSpace(username)) return;

            var password = Prompt("Create User", "Enter password:", "123456");
            if (string.IsNullOrWhiteSpace(password)) return;

            int id = IdManager.GetInstance().GenerateUniqueId();

            if (role.Equals("student", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Student>(Utils.STUDENT);
                if (list.Any(s => s.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("Student username already exists.");
                    return;
                }
                var s = new Student(id, password, username, "", $"{username}@mail.com", "0000000000", "Unknown");
                FileManager.SaveEntity(s, Utils.STUDENT);
                MessageBox.Show("Student created.");
                Log($"Student created: {username} ({id})");
            }
            else if (role.Equals("teacher", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Teacher>(Utils.TEACHER);
                if (list.Any(t => t.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("Teacher username already exists.");
                    return;
                }
                var t = new Teacher(id, password, username, "", $"{username}@mail.com", "0000000000", "Unknown");
                FileManager.SaveEntity(t, Utils.TEACHER);
                MessageBox.Show("Teacher created.");
                Log($"Teacher created: {username} ({id})");
            }
            else if (role.Equals("admin", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Admin>(Utils.ADMIN);
                if (list.Any(a => a.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("Admin username already exists.");
                    return;
                }
                var a = new Admin(id, password, username, "", $"{username}@mail.com", "0000000000", "Unknown");
                FileManager.SaveEntity(a, Utils.ADMIN);
                MessageBox.Show("Admin created.");
                Log($"Admin created: {username} ({id})");
            }
            else
            {
                MessageBox.Show("Invalid role. Use student/teacher/admin.");
            }
        }

        private void EditUserPassword()
        {
            var role = Prompt("Edit User", "Enter role (student/teacher/admin):", "student");
            if (role == null) return;

            var username = Prompt("Edit User", "Enter username to edit:");
            if (string.IsNullOrWhiteSpace(username)) return;

            var newPass = Prompt("Edit User", "Enter new password:");
            if (string.IsNullOrWhiteSpace(newPass)) return;

            if (role.Equals("student", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Student>(Utils.STUDENT);
                var target = list.FirstOrDefault(s => s.firstName.Equals(username, StringComparison.OrdinalIgnoreCase));
                if (target == null) { MessageBox.Show("Student not found."); return; }
                target.password = newPass;
                SaveJsonlOverwrite(Utils.STUDENT, list);
                MessageBox.Show("Student password updated.");
                Log($"Student password updated: {username}");
            }
            else if (role.Equals("teacher", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Teacher>(Utils.TEACHER);
                var target = list.FirstOrDefault(t => t.firstName.Equals(username, StringComparison.OrdinalIgnoreCase));
                if (target == null) { MessageBox.Show("Teacher not found."); return; }
                target.password = newPass;
                SaveJsonlOverwrite(Utils.TEACHER, list);
                MessageBox.Show("Teacher password updated.");
                Log($"Teacher password updated: {username}");
            }
            else if (role.Equals("admin", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Admin>(Utils.ADMIN);
                var target = list.FirstOrDefault(a => a.firstName.Equals(username, StringComparison.OrdinalIgnoreCase));
                if (target == null) { MessageBox.Show("Admin not found."); return; }
                target.password = newPass;
                SaveJsonlOverwrite(Utils.ADMIN, list);
                MessageBox.Show("Admin password updated.");
                Log($"Admin password updated: {username}");
            }
        }

        private void DeleteUser()
        {
            var role = Prompt("Delete User", "Enter role (student/teacher/admin):", "student");
            if (role == null) return;

            var username = Prompt("Delete User", "Enter username to delete:");
            if (string.IsNullOrWhiteSpace(username)) return;

            if (role.Equals("student", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Student>(Utils.STUDENT);
                var newList = list.Where(s => !s.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)).ToList();
                if (newList.Count == list.Count) { MessageBox.Show("Student not found."); return; }
                SaveJsonlOverwrite(Utils.STUDENT, newList);
                MessageBox.Show("Student deleted.");
                Log($"Student deleted: {username}");
            }
            else if (role.Equals("teacher", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Teacher>(Utils.TEACHER);
                var newList = list.Where(t => !t.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)).ToList();
                if (newList.Count == list.Count) { MessageBox.Show("Teacher not found."); return; }
                SaveJsonlOverwrite(Utils.TEACHER, newList);
                MessageBox.Show("Teacher deleted.");
                Log($"Teacher deleted: {username}");
            }
            else if (role.Equals("admin", StringComparison.OrdinalIgnoreCase))
            {
                var list = FileManager.LoadEntities<Admin>(Utils.ADMIN);
                var newList = list.Where(a => !a.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)).ToList();
                if (newList.Count == list.Count) { MessageBox.Show("Admin not found."); return; }
                SaveJsonlOverwrite(Utils.ADMIN, newList);
                MessageBox.Show("Admin deleted.");
                Log($"Admin deleted: {username}");
            }
        }

        private void AssignRole()
        {
            var username = Prompt("Assign Role", "Enter username to move role:");
            if (string.IsNullOrWhiteSpace(username)) return;

            var toRole = Prompt("Assign Role", "Move to which role? (student/teacher):", "teacher");
            if (toRole == null) return;

            // try move from student → teacher
            var students = FileManager.LoadEntities<Student>(Utils.STUDENT);
            var s = students.FirstOrDefault(x => x.firstName.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (s != null && toRole.Equals("teacher", StringComparison.OrdinalIgnoreCase))
            {
                // remove from students
                students = students.Where(x => !x.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)).ToList();
                SaveJsonlOverwrite(Utils.STUDENT, students);

                // add to teachers
                var teachers = FileManager.LoadEntities<Teacher>(Utils.TEACHER);
                teachers.Add(new Teacher(s.id, s.password, s.firstName, s.lastName, s.email, s.phone, s.address));
                SaveJsonlOverwrite(Utils.TEACHER, teachers);

                MessageBox.Show("Role changed: Student → Teacher");
                Log($"Role changed: {username} Student→Teacher");
                return;
            }

            // move teacher → student
            var teachers2 = FileManager.LoadEntities<Teacher>(Utils.TEACHER);
            var t = teachers2.FirstOrDefault(x => x.firstName.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (t != null && toRole.Equals("student", StringComparison.OrdinalIgnoreCase))
            {
                teachers2 = teachers2.Where(x => !x.firstName.Equals(username, StringComparison.OrdinalIgnoreCase)).ToList();
                SaveJsonlOverwrite(Utils.TEACHER, teachers2);

                var students2 = FileManager.LoadEntities<Student>(Utils.STUDENT);
                students2.Add(new Student(t.id, t.password, t.firstName, t.lastName, t.email, t.phone, t.address));
                SaveJsonlOverwrite(Utils.STUDENT, students2);

                MessageBox.Show("Role changed: Teacher → Student");
                Log($"Role changed: {username} Teacher→Student");
                return;
            }

            MessageBox.Show("User not found in source role, or invalid target role.");
        }

        // -------------------- MANAGE AWARDS --------------------
        // Wire to btnManageAwards.Click
        private void btnManageAwards_Click(object sender, EventArgs e)
        {
            var action = Prompt("Manage Awards", "Type action: add, edit, delete, list", "list");
            if (action == null) return;
            var awards = LoadJsonl<Award>(_awardsPath);

            switch (action.Trim().ToLowerInvariant())
            {
                case "list":
                    MessageBox.Show(awards.Any()
                        ? string.Join(Environment.NewLine, awards.Select(a => $"{a.title} → {a.student}"))
                        : "No awards yet.", "Awards");
                    break;

                case "add":
                    {
                        var title = Prompt("Add Award", "Award title:");
                        if (string.IsNullOrWhiteSpace(title)) return;
                        var student = Prompt("Add Award", "Student username (firstName):");
                        if (string.IsNullOrWhiteSpace(student)) return;
                        var desc = Prompt("Add Award", "Description:");
                        awards.Add(new Award(title, student, desc ?? "", DateTime.Now));
                        SaveJsonlOverwrite(_awardsPath, awards);
                        MessageBox.Show("Award added.");
                        Log($"Award added: {title} → {student}");
                        break;
                    }
                case "edit":
                    {
                        var title = Prompt("Edit Award", "Existing award title to edit:");
                        if (string.IsNullOrWhiteSpace(title)) return;
                        var award = awards.FirstOrDefault(a => a.title.Equals(title, StringComparison.OrdinalIgnoreCase));
                        if (award == null) { MessageBox.Show("Award not found."); return; }
                        var newDesc = Prompt("Edit Award", "New description:", award.description);
                        var idx = awards.IndexOf(award);
                        awards[idx] = award with { description = newDesc ?? award.description };
                        SaveJsonlOverwrite(_awardsPath, awards);
                        MessageBox.Show("Award updated.");
                        Log($"Award edited: {title}");
                        break;
                    }
                case "delete":
                    {
                        var title = Prompt("Delete Award", "Award title to delete:");
                        if (string.IsNullOrWhiteSpace(title)) return;
                        var newList = awards.Where(a => !a.title.Equals(title, StringComparison.OrdinalIgnoreCase)).ToList();
                        if (newList.Count == awards.Count) { MessageBox.Show("Award not found."); return; }
                        SaveJsonlOverwrite(_awardsPath, newList);
                        MessageBox.Show("Award deleted.");
                        Log($"Award deleted: {title}");
                        break;
                    }
                default:
                    MessageBox.Show("Unknown action. Use: add, edit, delete, list");
                    break;
            }
        }

        // -------------------- MANAGE COMPETITIONS --------------------
        // Wire to btnManageCompetitions.Click
        private void btnManageCompetitions_Click(object sender, EventArgs e)
        {
            var action = Prompt("Manage Competitions", "Type action: add, edit, delete, list", "list");
            if (action == null) return;

            var comps = LoadJsonl<Competition>(_competitionsPath);
            switch (action.Trim().ToLowerInvariant())
            {
                case "list":
                    MessageBox.Show(comps.Any()
                        ? string.Join(Environment.NewLine, comps.Select(c => c.name))
                        : "No competitions yet.", "Competitions");
                    break;

                case "add":
                    {
                        var name = Prompt("Add Competition", "Competition name:");
                        if (string.IsNullOrWhiteSpace(name)) return;
                        var rules = Prompt("Add Competition", "Rules:");
                        comps.Add(new Competition(name, rules ?? "", DateTime.Now));
                        SaveJsonlOverwrite(_competitionsPath, comps);
                        MessageBox.Show("Competition added.");
                        Log($"Competition added: {name}");
                        break;
                    }
                case "edit":
                    {
                        var name = Prompt("Edit Competition", "Existing competition name:");
                        if (string.IsNullOrWhiteSpace(name)) return;
                        var comp = comps.FirstOrDefault(c => c.name.Equals(name, StringComparison.OrdinalIgnoreCase));
                        if (comp == null) { MessageBox.Show("Competition not found."); return; }
                        var newRules = Prompt("Edit Competition", "New rules:", comp.rules);
                        var idx = comps.IndexOf(comp);
                        comps[idx] = comp with { rules = newRules ?? comp.rules };
                        SaveJsonlOverwrite(_competitionsPath, comps);
                        MessageBox.Show("Competition updated.");
                        Log($"Competition updated: {name}");
                        break;
                    }
                case "delete":
                    {
                        var name = Prompt("Delete Competition", "Competition name to delete:");
                        if (string.IsNullOrWhiteSpace(name)) return;
                        var newList = comps.Where(c => !c.name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
                        if (newList.Count == comps.Count) { MessageBox.Show("Competition not found."); return; }
                        SaveJsonlOverwrite(_competitionsPath, newList);
                        MessageBox.Show("Competition deleted.");
                        Log($"Competition deleted: {name}");
                        break;
                    }
                default:
                    MessageBox.Show("Unknown action. Use: add, edit, delete, list");
                    break;
            }
        }

        // -------------------- POST MANAGEMENT --------------------
        // Wire to btnPosts.Click (or btnPostManagement)
        private void btnPosts_Click(object sender, EventArgs e)
        {
            var action = Prompt("Post Management", "Type action: add, edit, delete, list", "list");
            if (action == null) return;

            var posts = LoadJsonl<Post>(_postsPath);
            switch (action.Trim().ToLowerInvariant())
            {
                case "list":
                    MessageBox.Show(posts.Any()
                        ? string.Join(Environment.NewLine, posts.Select(p => p.title))
                        : "No posts yet.", "Posts");
                    break;

                case "add":
                    {
                        var title = Prompt("Add Post", "Title:");
                        if (string.IsNullOrWhiteSpace(title)) return;
                        var content = Prompt("Add Post", "Content:");
                        posts.Add(new Post(title, content ?? "", DateTime.Now));
                        SaveJsonlOverwrite(_postsPath, posts);
                        MessageBox.Show("Post added.");
                        Log($"Post added: {title}");
                        break;
                    }
                case "edit":
                    {
                        var title = Prompt("Edit Post", "Existing title:");
                        if (string.IsNullOrWhiteSpace(title)) return;
                        var post = posts.FirstOrDefault(p => p.title.Equals(title, StringComparison.OrdinalIgnoreCase));
                        if (post == null) { MessageBox.Show("Post not found."); return; }
                        var newContent = Prompt("Edit Post", "New content:", post.content);
                        var idx = posts.IndexOf(post);
                        posts[idx] = post with { content = newContent ?? post.content };
                        SaveJsonlOverwrite(_postsPath, posts);
                        MessageBox.Show("Post updated.");
                        Log($"Post updated: {title}");
                        break;
                    }
                case "delete":
                    {
                        var title = Prompt("Delete Post", "Title to delete:");
                        if (string.IsNullOrWhiteSpace(title)) return;
                        var newList = posts.Where(p => !p.title.Equals(title, StringComparison.OrdinalIgnoreCase)).ToList();
                        if (newList.Count == posts.Count) { MessageBox.Show("Post not found."); return; }
                        SaveJsonlOverwrite(_postsPath, newList);
                        MessageBox.Show("Post deleted.");
                        Log($"Post deleted: {title}");
                        break;
                    }
                default:
                    MessageBox.Show("Unknown action. Use: add, edit, delete, list");
                    break;
            }
        }

        // -------------------- SYSTEM MONITORING --------------------
        // Wire to btnSystem.Click
        private void btnSystem_Click(object sender, EventArgs e)
        {
            // Simple viewer for logs and quick announcement
            var mode = Prompt("System Monitoring", "Type: viewlogs or announce", "viewlogs");
            if (mode == null) return;

            if (mode.Equals("viewlogs", StringComparison.OrdinalIgnoreCase))
            {
                var lines = File.Exists(_logsPath) ? File.ReadAllLines(_logsPath) : Array.Empty<string>();
                MessageBox.Show(lines.Any() ? string.Join(Environment.NewLine, lines) : "No logs yet.", "Logs");
            }
            else if (mode.Equals("announce", StringComparison.OrdinalIgnoreCase))
            {
                var msg = Prompt("Announcement", "Enter announcement text:");
                if (string.IsNullOrWhiteSpace(msg)) return;
                // Save as Post too:
                var posts = LoadJsonl<Post>(_postsPath);
                posts.Add(new Post("[Announcement] " + DateTime.Now.ToString("yyyy-MM-dd HH:mm"), msg, DateTime.Now));
                SaveJsonlOverwrite(_postsPath, posts);
                Log($"Announcement posted.");
                MessageBox.Show("Announcement posted.");
            }
        }

        // -------------------- AWARDS & LEADERBOARD OVERSIGHT --------------------
        // Wire to btnAwardsLeaderboard.Click
        private void btnAwardsLeaderboard_Click(object sender, EventArgs e)
        {
            var what = Prompt("Awards & Leaderboard", "Type: awards or leaderboard", "awards");
            if (what == null) return;

            if (what.Equals("awards", StringComparison.OrdinalIgnoreCase))
            {
                // Just call awards manager in "list/edit/delete" quickly
                btnManageAwards_Click(sender, e);
                return;
            }

            if (what.Equals("leaderboard", StringComparison.OrdinalIgnoreCase))
            {
                var action = Prompt("Leaderboard", "Type action: add, edit, delete, list", "list");
                if (action == null) return;

                var entries = LoadJsonl<LeaderboardEntry>(_leaderboardPath);
                switch (action.Trim().ToLowerInvariant())
                {
                    case "list":
                        MessageBox.Show(entries.Any()
                            ? string.Join(Environment.NewLine, entries.Select(le => $"{le.competition} | {le.student} → {le.score}"))
                            : "No leaderboard entries.", "Leaderboard");
                        break;

                    case "add":
                        {
                            var comp = Prompt("Add Entry", "Competition name:");
                            if (string.IsNullOrWhiteSpace(comp)) return;
                            var student = Prompt("Add Entry", "Student username:");
                            if (string.IsNullOrWhiteSpace(student)) return;
                            var scoreStr = Prompt("Add Entry", "Score (0-100):", "0");
                            if (!int.TryParse(scoreStr, out int score) || score < 0 || score > 100)
                            {
                                MessageBox.Show("Invalid score.");
                                return;
                            }
                            entries.Add(new LeaderboardEntry(comp, student, score, DateTime.Now));
                            SaveJsonlOverwrite(_leaderboardPath, entries);
                            MessageBox.Show("Entry added.");
                            Log($"Leaderboard add: {comp} | {student} → {score}");
                            break;
                        }
                    case "edit":
                        {
                            var comp = Prompt("Edit Entry", "Competition name to edit:");
                            var student = Prompt("Edit Entry", "Student username to edit:");
                            var entry = entries.FirstOrDefault(le =>
                                le.competition.Equals(comp ?? "", StringComparison.OrdinalIgnoreCase) &&
                                le.student.Equals(student ?? "", StringComparison.OrdinalIgnoreCase));
                            if (entry == null) { MessageBox.Show("Entry not found."); return; }
                            var newScoreStr = Prompt("Edit Entry", "New score (0-100):", entry.score.ToString());
                            if (!int.TryParse(newScoreStr, out int newScore) || newScore < 0 || newScore > 100)
                            {
                                MessageBox.Show("Invalid score.");
                                return;
                            }
                            var idx = entries.IndexOf(entry);
                            entries[idx] = entry with { score = newScore };
                            SaveJsonlOverwrite(_leaderboardPath, entries);
                            MessageBox.Show("Entry updated.");
                            Log($"Leaderboard edit: {comp} | {student} → {newScore}");
                            break;
                        }
                    case "delete":
                        {
                            var comp = Prompt("Delete Entry", "Competition name:");
                            var student = Prompt("Delete Entry", "Student username:");
                            var newList = entries.Where(le =>
                                !le.competition.Equals(comp ?? "", StringComparison.OrdinalIgnoreCase) ||
                                !le.student.Equals(student ?? "", StringComparison.OrdinalIgnoreCase)).ToList();
                            if (newList.Count == entries.Count) { MessageBox.Show("Entry not found."); return; }
                            SaveJsonlOverwrite(_leaderboardPath, newList);
                            MessageBox.Show("Entry deleted.");
                            Log($"Leaderboard delete: {comp} | {student}");
                            break;
                        }
                    default:
                        MessageBox.Show("Unknown action. Use: add, edit, delete, list");
                        break;
                }
                return;
            }

            MessageBox.Show("Unknown option. Type 'awards' or 'leaderboard'.");
        }

        // -------------------- LOG OUT --------------------
        private void btnLogout_Click(object sender, EventArgs e)
        {
            Log("Admin logged out.");
            var login = new LogIn();
            login.StartPosition = FormStartPosition.CenterScreen;
            login.Show();
            this.Hide();
        }
    }
}
