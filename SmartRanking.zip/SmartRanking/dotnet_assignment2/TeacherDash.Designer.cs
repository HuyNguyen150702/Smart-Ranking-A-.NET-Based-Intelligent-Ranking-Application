﻿using System.Windows.Forms;

namespace dotnet_assignment2
{
    partial class TeacherDash
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblWelcome;

        private ListBox listCompetitions;
        private TextBox txtCompName;
        private TextBox txtCompRules;
        private Button btnAddComp;
        private Button btnUpdateComp;
        private Button btnDeleteComp;

        private TabControl tabDetails;
        private TabPage tabLeaderboard;
        private TextBox txtLeaderboard;

        private GroupBox grpPost;
        private TextBox txtPostTitle;
        private TextBox txtPostContent;
        private Button btnAddPost;

        private GroupBox grpGrade;
        private TextBox txtCompForGrade;
        private TextBox txtStudentForGrade;
        private TextBox txtScore;
        private TextBox txtFeedback;
        private Button btnGrade;

        private GroupBox grpAwards;
        private ComboBox cboAwardCompetition;
        private TextBox txtAwardTitle;
        private TextBox txtAwardStudent;
        private TextBox txtAwardDesc;
        private Button btnGiveAward;

        private Button btnRefresh;
        private Button btnLogout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.listCompetitions = new System.Windows.Forms.ListBox();
            this.txtCompName = new System.Windows.Forms.TextBox();
            this.txtCompRules = new System.Windows.Forms.TextBox();
            this.btnAddComp = new System.Windows.Forms.Button();
            this.btnUpdateComp = new System.Windows.Forms.Button();
            this.btnDeleteComp = new System.Windows.Forms.Button();
            this.tabDetails = new System.Windows.Forms.TabControl();
            this.tabLeaderboard = new System.Windows.Forms.TabPage();
            this.txtLeaderboard = new System.Windows.Forms.TextBox();
            this.grpPost = new System.Windows.Forms.GroupBox();
            this.txtPostTitle = new System.Windows.Forms.TextBox();
            this.txtPostContent = new System.Windows.Forms.TextBox();
            this.btnAddPost = new System.Windows.Forms.Button();
            this.grpGrade = new System.Windows.Forms.GroupBox();
            this.txtCompForGrade = new System.Windows.Forms.TextBox();
            this.txtStudentForGrade = new System.Windows.Forms.TextBox();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.txtFeedback = new System.Windows.Forms.TextBox();
            this.btnGrade = new System.Windows.Forms.Button();
            this.grpAwards = new System.Windows.Forms.GroupBox();
            this.cboAwardCompetition = new System.Windows.Forms.ComboBox();
            this.txtAwardTitle = new System.Windows.Forms.TextBox();
            this.txtAwardStudent = new System.Windows.Forms.TextBox();
            this.txtAwardDesc = new System.Windows.Forms.TextBox();
            this.btnGiveAward = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.tabDetails.SuspendLayout();
            this.tabLeaderboard.SuspendLayout();
            this.grpPost.SuspendLayout();
            this.grpGrade.SuspendLayout();
            this.grpAwards.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.Location = new System.Drawing.Point(12, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(130, 21);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome, User!";
            // 
            // listCompetitions
            // 
            this.listCompetitions.FormattingEnabled = true;
            this.listCompetitions.ItemHeight = 15;
            this.listCompetitions.Location = new System.Drawing.Point(16, 44);
            this.listCompetitions.Name = "listCompetitions";
            this.listCompetitions.Size = new System.Drawing.Size(240, 319);
            this.listCompetitions.TabIndex = 1;
            this.listCompetitions.SelectedIndexChanged += new System.EventHandler(this.listCompetitions_SelectedIndexChanged);
            // 
            // txtCompName
            // 
            this.txtCompName.Location = new System.Drawing.Point(270, 44);
            this.txtCompName.Name = "txtCompName";
            this.txtCompName.PlaceholderText = "Competition name";
            this.txtCompName.Size = new System.Drawing.Size(380, 23);
            this.txtCompName.TabIndex = 2;
            // 
            // txtCompRules
            // 
            this.txtCompRules.Location = new System.Drawing.Point(270, 73);
            this.txtCompRules.Multiline = true;
            this.txtCompRules.Name = "txtCompRules";
            this.txtCompRules.PlaceholderText = "Rules / objectives";
            this.txtCompRules.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCompRules.Size = new System.Drawing.Size(380, 110);
            this.txtCompRules.TabIndex = 3;
            // 
            // btnAddComp
            // 
            this.btnAddComp.Location = new System.Drawing.Point(270, 189);
            this.btnAddComp.Name = "btnAddComp";
            this.btnAddComp.Size = new System.Drawing.Size(120, 27);
            this.btnAddComp.TabIndex = 4;
            this.btnAddComp.Text = "Add";
            this.btnAddComp.UseVisualStyleBackColor = true;
            this.btnAddComp.Click += new System.EventHandler(this.btnAddComp_Click);
            // 
            // btnUpdateComp
            // 
            this.btnUpdateComp.Location = new System.Drawing.Point(396, 189);
            this.btnUpdateComp.Name = "btnUpdateComp";
            this.btnUpdateComp.Size = new System.Drawing.Size(120, 27);
            this.btnUpdateComp.TabIndex = 5;
            this.btnUpdateComp.Text = "Update";
            this.btnUpdateComp.UseVisualStyleBackColor = true;
            this.btnUpdateComp.Click += new System.EventHandler(this.btnUpdateComp_Click);
            // 
            // btnDeleteComp
            // 
            this.btnDeleteComp.Location = new System.Drawing.Point(530, 189);
            this.btnDeleteComp.Name = "btnDeleteComp";
            this.btnDeleteComp.Size = new System.Drawing.Size(120, 27);
            this.btnDeleteComp.TabIndex = 6;
            this.btnDeleteComp.Text = "Delete";
            this.btnDeleteComp.UseVisualStyleBackColor = true;
            this.btnDeleteComp.Click += new System.EventHandler(this.btnDeleteComp_Click);
            // 
            // tabDetails
            // 
            this.tabDetails.Controls.Add(this.tabLeaderboard);
            this.tabDetails.Location = new System.Drawing.Point(270, 232);
            this.tabDetails.Name = "tabDetails";
            this.tabDetails.SelectedIndex = 0;
            this.tabDetails.Size = new System.Drawing.Size(380, 131);
            this.tabDetails.TabIndex = 7;
            // 
            // tabLeaderboard
            // 
            this.tabLeaderboard.Controls.Add(this.txtLeaderboard);
            this.tabLeaderboard.Location = new System.Drawing.Point(4, 24);
            this.tabLeaderboard.Name = "tabLeaderboard";
            this.tabLeaderboard.Padding = new System.Windows.Forms.Padding(3);
            this.tabLeaderboard.Size = new System.Drawing.Size(372, 103);
            this.tabLeaderboard.TabIndex = 0;
            this.tabLeaderboard.Text = "Leaderboard";
            this.tabLeaderboard.UseVisualStyleBackColor = true;
            // 
            // txtLeaderboard
            // 
            this.txtLeaderboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLeaderboard.Location = new System.Drawing.Point(3, 3);
            this.txtLeaderboard.Multiline = true;
            this.txtLeaderboard.Name = "txtLeaderboard";
            this.txtLeaderboard.ReadOnly = true;
            this.txtLeaderboard.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLeaderboard.Size = new System.Drawing.Size(366, 97);
            this.txtLeaderboard.TabIndex = 0;
            // 
            // grpPost
            // 
            this.grpPost.Controls.Add(this.txtPostTitle);
            this.grpPost.Controls.Add(this.txtPostContent);
            this.grpPost.Controls.Add(this.btnAddPost);
            this.grpPost.Location = new System.Drawing.Point(668, 44);
            this.grpPost.Name = "grpPost";
            this.grpPost.Size = new System.Drawing.Size(300, 188);
            this.grpPost.TabIndex = 8;
            this.grpPost.TabStop = false;
            this.grpPost.Text = "Add Post / Announcement";
            // 
            // txtPostTitle
            // 
            this.txtPostTitle.Location = new System.Drawing.Point(14, 22);
            this.txtPostTitle.Name = "txtPostTitle";
            this.txtPostTitle.PlaceholderText = "Title";
            this.txtPostTitle.Size = new System.Drawing.Size(272, 23);
            this.txtPostTitle.TabIndex = 0;
            // 
            // txtPostContent
            // 
            this.txtPostContent.Location = new System.Drawing.Point(14, 51);
            this.txtPostContent.Multiline = true;
            this.txtPostContent.Name = "txtPostContent";
            this.txtPostContent.PlaceholderText = "Content";
            this.txtPostContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPostContent.Size = new System.Drawing.Size(272, 100);
            this.txtPostContent.TabIndex = 1;
            // 
            // btnAddPost
            // 
            this.btnAddPost.Location = new System.Drawing.Point(186, 157);
            this.btnAddPost.Name = "btnAddPost";
            this.btnAddPost.Size = new System.Drawing.Size(100, 25);
            this.btnAddPost.TabIndex = 2;
            this.btnAddPost.Text = "Publish";
            this.btnAddPost.UseVisualStyleBackColor = true;
            this.btnAddPost.Click += new System.EventHandler(this.btnAddPost_Click);
            // 
            // grpGrade
            // 
            this.grpGrade.Controls.Add(this.txtCompForGrade);
            this.grpGrade.Controls.Add(this.txtStudentForGrade);
            this.grpGrade.Controls.Add(this.txtScore);
            this.grpGrade.Controls.Add(this.txtFeedback);
            this.grpGrade.Controls.Add(this.btnGrade);
            this.grpGrade.Location = new System.Drawing.Point(668, 238);
            this.grpGrade.Name = "grpGrade";
            this.grpGrade.Size = new System.Drawing.Size(300, 225);
            this.grpGrade.TabIndex = 9;
            this.grpGrade.TabStop = false;
            this.grpGrade.Text = "Grade & Feedback";
            // 
            // txtCompForGrade
            // 
            this.txtCompForGrade.Location = new System.Drawing.Point(14, 22);
            this.txtCompForGrade.Name = "txtCompForGrade";
            this.txtCompForGrade.PlaceholderText = "Competition";
            this.txtCompForGrade.Size = new System.Drawing.Size(272, 23);
            this.txtCompForGrade.TabIndex = 0;
            // 
            // txtStudentForGrade
            // 
            this.txtStudentForGrade.Location = new System.Drawing.Point(14, 51);
            this.txtStudentForGrade.Name = "txtStudentForGrade";
            this.txtStudentForGrade.PlaceholderText = "Student username";
            this.txtStudentForGrade.Size = new System.Drawing.Size(272, 23);
            this.txtStudentForGrade.TabIndex = 1;
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(14, 80);
            this.txtScore.Name = "txtScore";
            this.txtScore.PlaceholderText = "Score (0-100)";
            this.txtScore.Size = new System.Drawing.Size(272, 23);
            this.txtScore.TabIndex = 2;
            // 
            // txtFeedback
            // 
            this.txtFeedback.Location = new System.Drawing.Point(14, 109);
            this.txtFeedback.Multiline = true;
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.PlaceholderText = "Feedback (optional)";
            this.txtFeedback.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtFeedback.Size = new System.Drawing.Size(272, 74);
            this.txtFeedback.TabIndex = 3;
            // 
            // btnGrade
            // 
            this.btnGrade.Location = new System.Drawing.Point(186, 189);
            this.btnGrade.Name = "btnGrade";
            this.btnGrade.Size = new System.Drawing.Size(100, 25);
            this.btnGrade.TabIndex = 4;
            this.btnGrade.Text = "Save";
            this.btnGrade.UseVisualStyleBackColor = true;
            this.btnGrade.Click += new System.EventHandler(this.btnGrade_Click);
            // 
            // grpAwards
            // 
            this.grpAwards.Controls.Add(this.cboAwardCompetition);
            this.grpAwards.Controls.Add(this.txtAwardTitle);
            this.grpAwards.Controls.Add(this.txtAwardStudent);
            this.grpAwards.Controls.Add(this.txtAwardDesc);
            this.grpAwards.Controls.Add(this.btnGiveAward);
            this.grpAwards.Location = new System.Drawing.Point(270, 371);
            this.grpAwards.Name = "grpAwards";
            this.grpAwards.Size = new System.Drawing.Size(380, 180);
            this.grpAwards.TabIndex = 12;
            this.grpAwards.TabStop = false;
            this.grpAwards.Text = "Create Award";
            // 
            // cboAwardCompetition
            // 
            this.cboAwardCompetition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAwardCompetition.Location = new System.Drawing.Point(16, 22);
            this.cboAwardCompetition.Name = "cboAwardCompetition";
            this.cboAwardCompetition.Size = new System.Drawing.Size(348, 23);
            this.cboAwardCompetition.TabIndex = 0;
            // 
            // txtAwardTitle
            // 
            this.txtAwardTitle.Location = new System.Drawing.Point(16, 51);
            this.txtAwardTitle.Name = "txtAwardTitle";
            this.txtAwardTitle.PlaceholderText = "Award title";
            this.txtAwardTitle.Size = new System.Drawing.Size(348, 23);
            this.txtAwardTitle.TabIndex = 1;
            // 
            // txtAwardStudent
            // 
            this.txtAwardStudent.Location = new System.Drawing.Point(16, 80);
            this.txtAwardStudent.Name = "txtAwardStudent";
            this.txtAwardStudent.PlaceholderText = "Student username";
            this.txtAwardStudent.Size = new System.Drawing.Size(348, 23);
            this.txtAwardStudent.TabIndex = 2;
            // 
            // txtAwardDesc
            // 
            this.txtAwardDesc.Location = new System.Drawing.Point(16, 109);
            this.txtAwardDesc.Multiline = true;
            this.txtAwardDesc.Name = "txtAwardDesc";
            this.txtAwardDesc.PlaceholderText = "Description (optional)";
            this.txtAwardDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAwardDesc.Size = new System.Drawing.Size(348, 38);
            this.txtAwardDesc.TabIndex = 3;
            // 
            // btnGiveAward
            // 
            this.btnGiveAward.Location = new System.Drawing.Point(264, 151);
            this.btnGiveAward.Name = "btnGiveAward";
            this.btnGiveAward.Size = new System.Drawing.Size(100, 24);
            this.btnGiveAward.TabIndex = 4;
            this.btnGiveAward.Text = "Give Award";
            this.btnGiveAward.UseVisualStyleBackColor = true;
            this.btnGiveAward.Click += new System.EventHandler(this.btnGiveAward_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(16, 371);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(120, 30);
            this.btnRefresh.TabIndex = 10;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(152, 371);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(120, 30);
            this.btnLogout.TabIndex = 11;
            this.btnLogout.Text = "Log out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // TeacherDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 581);
            this.Controls.Add(this.grpAwards);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.grpGrade);
            this.Controls.Add(this.grpPost);
            this.Controls.Add(this.tabDetails);
            this.Controls.Add(this.btnDeleteComp);
            this.Controls.Add(this.btnUpdateComp);
            this.Controls.Add(this.btnAddComp);
            this.Controls.Add(this.txtCompRules);
            this.Controls.Add(this.txtCompName);
            this.Controls.Add(this.listCompetitions);
            this.Controls.Add(this.lblWelcome);
            this.Name = "TeacherDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teacher Mode";
            this.tabDetails.ResumeLayout(false);
            this.tabLeaderboard.ResumeLayout(false);
            this.tabLeaderboard.PerformLayout();
            this.grpPost.ResumeLayout(false);
            this.grpPost.PerformLayout();
            this.grpGrade.ResumeLayout(false);
            this.grpGrade.PerformLayout();
            this.grpAwards.ResumeLayout(false);
            this.grpAwards.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
