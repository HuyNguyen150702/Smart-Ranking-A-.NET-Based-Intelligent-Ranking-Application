using System;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace dotnet_assignment2
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();

            // Ensure data dir + default files + default admin
            FileManager.EnsureDataDirectoryAndFiles();

            // Mask password
            if (TxtPassword != null)
                TxtPassword.UseSystemPasswordChar = true;
        }

        // ===== LOG IN =====
        private void button1_Click(object sender, EventArgs e)
        {
            string user = TxtUsername.Text.Trim();
            string pass = TxtPassword.Text;

            if (string.IsNullOrWhiteSpace(user))
            {
                MessageBox.Show("Please enter your username.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtUsername.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Please enter your password.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtPassword.Focus();
                return;
            }

            // 1) STUDENT
            var students = FileManager.LoadEntities<Student>(Utils.STUDENT);
            var sMatch = students.FirstOrDefault(s =>
                s.firstName.Equals(user, StringComparison.OrdinalIgnoreCase) &&
                s.password == pass);

            if (sMatch != null)
            {
                MessageBox.Show($"Welcome (Student) {sMatch.firstName}!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                var studentForm = new StudentDash(sMatch.firstName);
                studentForm.StartPosition = FormStartPosition.CenterScreen;
                studentForm.Show();
                this.Hide();
                return;
            }

            // 2) TEACHER
            var teachers = FileManager.LoadEntities<Teacher>(Utils.TEACHER);
            var tMatch = teachers.FirstOrDefault(t =>
                t.firstName.Equals(user, StringComparison.OrdinalIgnoreCase) &&
                t.password == pass);

            if (tMatch != null)
            {
                MessageBox.Show($"Welcome (Teacher) {tMatch.firstName}!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // If you renamed Form4 to TeacherDash, replace Form4 with TeacherDash below.
                var teacherForm = new TeacherDash(tMatch.firstName);
                teacherForm.StartPosition = FormStartPosition.CenterScreen;
                teacherForm.Show();
                this.Hide();
                return;
            }

            // 3) ADMIN
            var admins = FileManager.LoadEntities<Admin>(Utils.ADMIN);
            var aMatch = admins.FirstOrDefault(a =>
                a.firstName.Equals(user, StringComparison.OrdinalIgnoreCase) &&
                a.password == pass);

            if (aMatch != null)
            {
                MessageBox.Show($"Welcome (Admin) {aMatch.firstName}!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // If you renamed Form5 to AdminDash, replace Form5 with AdminDash below.
                var adminForm = new Form5();
                adminForm.StartPosition = FormStartPosition.CenterScreen;
                adminForm.Show();
                this.Hide();
                return;
            }

            // No match
            MessageBox.Show("Invalid Username or Password", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            TxtUsername.Clear();
            TxtPassword.Clear();
            TxtUsername.Focus();
        }

        // ===== CLEAR FIELDS =====
        private void label4_Click(object sender, EventArgs e)
        {
            TxtUsername.Clear();
            TxtPassword.Clear();
            TxtUsername.Focus();
        }

        // ===== EXIT =====
        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // ===== GO TO REGISTER (Create Account) =====
        private void label7_Click(object sender, EventArgs e)
        {
            var registerForm = new Register();
            registerForm.StartPosition = FormStartPosition.CenterScreen;
            registerForm.Show();
            this.Hide();
        }

        // ===== Optional no-op stubs for Designer-wired events =====
        private void LogIn_Load(object sender, EventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void pictureBox2_Click(object sender, EventArgs e) { }
        private void pictureBox3_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void TxtUsername_TextChanged(object sender, EventArgs e) { }
    }
}
