﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotnet_assignment2 {
    public class Utils {
        private static readonly Func<string, string, string> _buildPath = (baseDir, fileName) =>
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, baseDir, fileName);

        // The constants are database stored in txt file
        // for example the admin data is stored in data/admin.txt
        public static readonly string ID_LIST = _buildPath("data", "id_list.txt");

        public static readonly string ADMIN = _buildPath("data", "admin.txt");

        public static readonly string STUDENT = _buildPath("data", "student.txt");

        public static readonly string TEACHER = _buildPath("data", "teacher.txt");

    }
}
