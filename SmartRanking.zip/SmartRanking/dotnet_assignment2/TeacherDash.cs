﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace dotnet_assignment2
{
    public partial class TeacherDash : Form
    {
        private readonly string _teacherName;

        private readonly string _competitionsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "competitions.txt");
        private readonly string _leaderboardPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "leaderboard.txt");
        private readonly string _postsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "posts.txt");
        private readonly string _feedbackPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "feedback.txt");
        private readonly string _awardsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "awards.txt");

        // -------- Data classes (POCOs; no records) --------
        private class Competition
        {
            public string name { get; set; }
            public string rules { get; set; }
            public DateTime createdAt { get; set; }
            public Competition() { }
            public Competition(string n, string r, DateTime t) { name = n; rules = r; createdAt = t; }
        }

        private class LeaderboardEntry
        {
            public string competition { get; set; }
            public string student { get; set; }
            public int score { get; set; }
            public DateTime createdAt { get; set; }
            public LeaderboardEntry() { }
            public LeaderboardEntry(string c, string s, int sc, DateTime t) { competition = c; student = s; score = sc; createdAt = t; }
        }

        private class Post
        {
            public string title { get; set; }
            public string content { get; set; }
            public DateTime createdAt { get; set; }
            public Post() { }
            public Post(string t, string c, DateTime d) { title = t; content = c; createdAt = d; }
        }

        private class FeedbackEntry
        {
            public string competition { get; set; }
            public string student { get; set; }
            public string teacher { get; set; }
            public string feedback { get; set; }
            public DateTime createdAt { get; set; }
            public FeedbackEntry() { }
            public FeedbackEntry(string c, string s, string t, string f, DateTime d)
            { competition = c; student = s; teacher = t; feedback = f; createdAt = d; }
        }

        private class Award
        {
            public string competition { get; set; }   // NEW: contest name saved with the award
            public string title { get; set; }
            public string student { get; set; }
            public string description { get; set; }
            public DateTime createdAt { get; set; }
            public Award() { }
            public Award(string c, string t, string s, string d, DateTime dt)
            { competition = c; title = t; student = s; description = d; createdAt = dt; }
        }

        private List<Competition> _comps = new List<Competition>();

        public TeacherDash() : this("Teacher") { }
        public TeacherDash(string teacherName)
        {
            InitializeComponent();
            _teacherName = string.IsNullOrWhiteSpace(teacherName) ? "Teacher" : teacherName;
            lblWelcome.Text = $"Welcome, {_teacherName}!";

            EnsureFiles();
            LoadCompetitionsIntoList();
        }

        // -------- File helpers --------
        private void EnsureFiles()
        {
            var dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");
            Directory.CreateDirectory(dir);
            Touch(_competitionsPath);
            Touch(_leaderboardPath);
            Touch(_postsPath);
            Touch(_feedbackPath);
            Touch(_awardsPath);
        }
        private static void Touch(string p) { if (!File.Exists(p)) File.Create(p).Dispose(); }

        // JSONL read/write
        private static List<T> LoadJsonl<T>(string path)
        {
            var list = new List<T>();
            if (!File.Exists(path)) return list;
            foreach (var line in File.ReadLines(path))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                try { var o = JsonSerializer.Deserialize<T>(line); if (o != null) list.Add(o); }
                catch { /* skip bad line */ }
            }
            return list;
        }
        private static void SaveJsonlOverwrite<T>(string path, IEnumerable<T> items)
            => File.WriteAllLines(path, items.Select(i => JsonSerializer.Serialize(i)));
        private static void AppendJsonl<T>(string path, T item)
            => File.AppendAllText(path, JsonSerializer.Serialize(item) + Environment.NewLine);

        // -------- Competitions UI --------
        private void LoadCompetitionsIntoList()
        {
            _comps = LoadJsonl<Competition>(_competitionsPath).OrderByDescending(c => c.createdAt).ToList();

            listCompetitions.Items.Clear();
            foreach (var c in _comps) listCompetitions.Items.Add(c.name);

            // sync awards competition dropdown
            cboAwardCompetition.Items.Clear();
            foreach (var c in _comps) cboAwardCompetition.Items.Add(c.name);
            if (cboAwardCompetition.Items.Count > 0 && cboAwardCompetition.SelectedIndex < 0)
                cboAwardCompetition.SelectedIndex = 0;

            txtCompName.Clear();
            txtCompRules.Clear();
            txtCompForGrade.Clear();
            txtLeaderboard.Clear();
        }

        private void listCompetitions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listCompetitions.SelectedIndex < 0 || listCompetitions.SelectedIndex >= _comps.Count) return;
            var c = _comps[listCompetitions.SelectedIndex];

            txtCompName.Text = c.name;
            txtCompRules.Text = c.rules;
            txtCompForGrade.Text = c.name;

            // keep award combo aligned
            var idx = cboAwardCompetition.Items.IndexOf(c.name);
            if (idx >= 0) cboAwardCompetition.SelectedIndex = idx;

            RenderLeaderboard(c.name);
        }

        private void btnAddComp_Click(object sender, EventArgs e)
        {
            var name = (txtCompName.Text ?? "").Trim();
            var rules = (txtCompRules.Text ?? "").Trim();
            if (string.IsNullOrWhiteSpace(name)) { MessageBox.Show("Enter competition name."); return; }

            if (_comps.Any(x => string.Equals((x.name ?? "").Trim(), name, StringComparison.OrdinalIgnoreCase)))
            { MessageBox.Show("A competition with this name already exists."); return; }

            AppendJsonl(_competitionsPath, new Competition(name, rules, DateTime.Now));
            MessageBox.Show("Competition created.");
            LoadCompetitionsIntoList();
        }

        private void btnUpdateComp_Click(object sender, EventArgs e)
        {
            if (listCompetitions.SelectedIndex < 0 || listCompetitions.SelectedIndex >= _comps.Count)
            { MessageBox.Show("Select a competition first."); return; }

            var original = _comps[listCompetitions.SelectedIndex];
            var newName = (txtCompName.Text ?? "").Trim();
            var newRules = (txtCompRules.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(newName)) { MessageBox.Show("Name cannot be empty."); return; }
            if (!string.Equals((original.name ?? "").Trim(), newName, StringComparison.OrdinalIgnoreCase) &&
                _comps.Any(c => string.Equals((c.name ?? "").Trim(), newName, StringComparison.OrdinalIgnoreCase)))
            { MessageBox.Show("Another competition already has that name."); return; }

            var all = LoadJsonl<Competition>(_competitionsPath);
            var idx = all.FindIndex(c => c.name == original.name && c.createdAt == original.createdAt);
            if (idx >= 0)
            {
                all[idx] = new Competition(newName, newRules, original.createdAt);
                SaveJsonlOverwrite(_competitionsPath, all);
                MessageBox.Show("Competition updated.");
                LoadCompetitionsIntoList();
            }
        }

        private void btnDeleteComp_Click(object sender, EventArgs e)
        {
            if (listCompetitions.SelectedIndex < 0 || listCompetitions.SelectedIndex >= _comps.Count)
            { MessageBox.Show("Select a competition first."); return; }

            var target = _comps[listCompetitions.SelectedIndex];
            var all = LoadJsonl<Competition>(_competitionsPath)
                     .Where(c => !(c.name == target.name && c.createdAt == target.createdAt)).ToList();

            SaveJsonlOverwrite(_competitionsPath, all);
            MessageBox.Show("Competition deleted.");
            LoadCompetitionsIntoList();
        }

        private void RenderLeaderboard(string compNameRaw)
        {
            var compName = (compNameRaw ?? "").Trim();
            var entries = LoadJsonl<LeaderboardEntry>(_leaderboardPath)
                         .Where(le => string.Equals((le.competition ?? "").Trim(), compName, StringComparison.OrdinalIgnoreCase))
                         .OrderByDescending(le => le.score).ToList();

            txtLeaderboard.Text = entries.Any()
                ? $"Leaderboard — {compName}{Environment.NewLine}" +
                  string.Join(Environment.NewLine, entries.Select((le, i) => $"{i + 1}. {le.student} — {le.score}"))
                : $"No leaderboard entries yet for {compName}.";
        }

        // -------- Posts --------
        private void btnAddPost_Click(object sender, EventArgs e)
        {
            var title = (txtPostTitle.Text ?? "").Trim();
            var content = (txtPostContent.Text ?? "").Trim();
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(content))
            { MessageBox.Show("Enter title and content."); return; }

            AppendJsonl(_postsPath, new Post(title, content, DateTime.Now));
            MessageBox.Show("Post published.");
            txtPostTitle.Clear();
            txtPostContent.Clear();
        }

        // -------- Grade & Feedback --------
        private void btnGrade_Click(object sender, EventArgs e)
        {
            var comp = (txtCompForGrade.Text ?? "").Trim();
            var student = (txtStudentForGrade.Text ?? "").Trim();
            var scoreStr = (txtScore.Text ?? "").Trim();
            var feedback = (txtFeedback.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(comp)) { MessageBox.Show("Competition is required."); return; }
            if (string.IsNullOrWhiteSpace(student)) { MessageBox.Show("Student username is required."); return; }
            if (!int.TryParse(scoreStr, out int score) || score < 0 || score > 100)
            { MessageBox.Show("Score must be 0–100."); return; }

            var entries = LoadJsonl<LeaderboardEntry>(_leaderboardPath);
            var exist = entries.FirstOrDefault(e =>
                string.Equals((e.competition ?? "").Trim(), comp, StringComparison.OrdinalIgnoreCase) &&
                string.Equals((e.student ?? "").Trim(), student, StringComparison.OrdinalIgnoreCase));

            if (exist == null) entries.Add(new LeaderboardEntry(comp, student, score, DateTime.Now));
            else
            {
                entries.Remove(exist);
                entries.Add(new LeaderboardEntry(comp, student, score, DateTime.Now));
            }
            SaveJsonlOverwrite(_leaderboardPath, entries);

            if (!string.IsNullOrWhiteSpace(feedback))
                AppendJsonl(_feedbackPath, new FeedbackEntry(comp, student, _teacherName, feedback, DateTime.Now));

            MessageBox.Show("Grade saved.");
            if (listCompetitions.SelectedIndex >= 0 &&
                listCompetitions.SelectedIndex < _comps.Count &&
                string.Equals((_comps[listCompetitions.SelectedIndex].name ?? "").Trim(), comp, StringComparison.OrdinalIgnoreCase))
            {
                RenderLeaderboard(comp);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadCompetitionsIntoList();
            if (listCompetitions.SelectedIndex >= 0 && listCompetitions.SelectedIndex < _comps.Count)
                RenderLeaderboard(_comps[listCompetitions.SelectedIndex].name);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var login = new LogIn();
            login.StartPosition = FormStartPosition.CenterScreen;
            login.Show();
            Close();
        }

        // -------- Awards (includes competition) --------
        private void btnGiveAward_Click(object sender, EventArgs e)
        {
            var comp = (cboAwardCompetition.SelectedItem as string ?? "").Trim();
            var title = (txtAwardTitle.Text ?? "").Trim();
            var student = (txtAwardStudent.Text ?? "").Trim();
            var desc = (txtAwardDesc.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(comp)) { MessageBox.Show("Select a competition."); return; }
            if (string.IsNullOrWhiteSpace(title)) { MessageBox.Show("Award title is required."); return; }
            if (string.IsNullOrWhiteSpace(student)) { MessageBox.Show("Student username is required."); return; }

            AppendJsonl(_awardsPath, new Award(comp, title, student, desc, DateTime.Now));
            MessageBox.Show("Award created.");

            txtAwardTitle.Clear();
            txtAwardStudent.Clear();
            txtAwardDesc.Clear();
        }
    }
}
