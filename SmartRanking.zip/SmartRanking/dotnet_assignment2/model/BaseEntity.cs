﻿namespace dotnet_assignment2;

public abstract class BaseEntity
{

    /**
     * A constructor that objects extend BaseEntity need to follow
     */
    protected BaseEntity(int id, string password, string firstName, string lastName, string email, string phone,
        string address)
    {
        this.id = id;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    // need public here for the json serialization / deserialization
    public int id { get; set; }
    public string password { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
    public string email { get; set; }
    public string phone { get; set; }
    public string address { get; set; }
}