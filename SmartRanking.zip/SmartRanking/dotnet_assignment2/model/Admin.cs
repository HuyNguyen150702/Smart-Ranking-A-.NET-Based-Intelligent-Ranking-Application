﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotnet_assignment2
{
    /**
     * Admin class is for storing admin to txt file
     * and also override MainMenu for displaying in console
     */
    public class Admin : BaseEntity
    {
        public Admin(
            int id, string password, string firstName, string lastName, string email,
            string phone, string address
        ) : base(id, password, firstName, lastName, email, phone, address)
        {
        }
    }
}