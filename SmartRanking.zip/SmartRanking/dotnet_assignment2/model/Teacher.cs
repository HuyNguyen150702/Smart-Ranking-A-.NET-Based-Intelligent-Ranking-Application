﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotnet_assignment2
{
    /**
     * Patient class for showing patient menu
     */
    public class Teacher : BaseEntity
    {
        public Teacher(
            int id, string password, string firstName, string lastName, string email,
            string phone, string address
        ) : base(id, password, firstName, lastName, email, phone, address)
        {
        }
    }
}