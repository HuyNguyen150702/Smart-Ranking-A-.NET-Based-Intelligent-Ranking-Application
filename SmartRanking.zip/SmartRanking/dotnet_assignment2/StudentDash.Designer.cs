﻿using System.Windows.Forms;

namespace dotnet_assignment2
{
    partial class StudentDash
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblWelcome;
        private ListBox listCompetitions;
        private ListBox listAwards;
        private TabControl tabDetails;
        private TabPage tabDetail;
        private TextBox txtDetail;
        private TabPage tabLeaderboard;
        private TextBox txtLeaderboard;
        private TextBox txtPosts;
        private TextBox txtFeedback;
        private Button btnSubmit;
        private Button btnRefresh;
        private Button btnLogout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.listCompetitions = new System.Windows.Forms.ListBox();
            this.listAwards = new System.Windows.Forms.ListBox();
            this.tabDetails = new System.Windows.Forms.TabControl();
            this.tabDetail = new System.Windows.Forms.TabPage();
            this.txtDetail = new System.Windows.Forms.TextBox();
            this.tabLeaderboard = new System.Windows.Forms.TabPage();
            this.txtLeaderboard = new System.Windows.Forms.TextBox();
            this.txtPosts = new System.Windows.Forms.TextBox();
            this.txtFeedback = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.tabDetails.SuspendLayout();
            this.tabDetail.SuspendLayout();
            this.tabLeaderboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.Location = new System.Drawing.Point(12, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(150, 21);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome, Student!";
            // 
            // listCompetitions
            // 
            this.listCompetitions.FormattingEnabled = true;
            this.listCompetitions.ItemHeight = 15;
            this.listCompetitions.Location = new System.Drawing.Point(16, 44);
            this.listCompetitions.Name = "listCompetitions";
            this.listCompetitions.Size = new System.Drawing.Size(240, 214);
            this.listCompetitions.TabIndex = 1;
            this.listCompetitions.SelectedIndexChanged += new System.EventHandler(this.listCompetitions_SelectedIndexChanged);
            // 
            // listAwards
            // 
            this.listAwards.FormattingEnabled = true;
            this.listAwards.ItemHeight = 15;
            this.listAwards.Location = new System.Drawing.Point(16, 270);
            this.listAwards.Name = "listAwards";
            this.listAwards.Size = new System.Drawing.Size(240, 169);
            this.listAwards.TabIndex = 2;
            this.listAwards.SelectedIndexChanged += new System.EventHandler(this.listAwards_SelectedIndexChanged);
            // 
            // tabDetails
            // 
            this.tabDetails.Controls.Add(this.tabDetail);
            this.tabDetails.Controls.Add(this.tabLeaderboard);
            this.tabDetails.Location = new System.Drawing.Point(270, 44);
            this.tabDetails.Name = "tabDetails";
            this.tabDetails.SelectedIndex = 0;
            this.tabDetails.Size = new System.Drawing.Size(380, 240);
            this.tabDetails.TabIndex = 3;
            // 
            // tabDetail
            // 
            this.tabDetail.Controls.Add(this.txtDetail);
            this.tabDetail.Location = new System.Drawing.Point(4, 24);
            this.tabDetail.Name = "tabDetail";
            this.tabDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetail.Size = new System.Drawing.Size(372, 212);
            this.tabDetail.TabIndex = 0;
            this.tabDetail.Text = "Detail";
            this.tabDetail.UseVisualStyleBackColor = true;
            // 
            // txtDetail
            // 
            this.txtDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDetail.Location = new System.Drawing.Point(3, 3);
            this.txtDetail.Multiline = true;
            this.txtDetail.Name = "txtDetail";
            this.txtDetail.ReadOnly = true;
            this.txtDetail.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDetail.Size = new System.Drawing.Size(366, 206);
            this.txtDetail.TabIndex = 0;
            this.txtDetail.TextChanged += new System.EventHandler(this.txtDetail_TextChanged);
            // 
            // tabLeaderboard
            // 
            this.tabLeaderboard.Controls.Add(this.txtLeaderboard);
            this.tabLeaderboard.Location = new System.Drawing.Point(4, 24);
            this.tabLeaderboard.Name = "tabLeaderboard";
            this.tabLeaderboard.Padding = new System.Windows.Forms.Padding(3);
            this.tabLeaderboard.Size = new System.Drawing.Size(372, 212);
            this.tabLeaderboard.TabIndex = 1;
            this.tabLeaderboard.Text = "Leaderboard";
            this.tabLeaderboard.UseVisualStyleBackColor = true;
            // 
            // txtLeaderboard
            // 
            this.txtLeaderboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLeaderboard.Location = new System.Drawing.Point(3, 3);
            this.txtLeaderboard.Multiline = true;
            this.txtLeaderboard.Name = "txtLeaderboard";
            this.txtLeaderboard.ReadOnly = true;
            this.txtLeaderboard.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLeaderboard.Size = new System.Drawing.Size(366, 206);
            this.txtLeaderboard.TabIndex = 0;
            // 
            // txtPosts
            // 
            this.txtPosts.Location = new System.Drawing.Point(270, 292);
            this.txtPosts.Multiline = true;
            this.txtPosts.Name = "txtPosts";
            this.txtPosts.ReadOnly = true;
            this.txtPosts.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPosts.Size = new System.Drawing.Size(380, 147);
            this.txtPosts.TabIndex = 4;
            this.txtPosts.TextChanged += new System.EventHandler(this.txtPosts_TextChanged);
            // 
            // txtFeedback
            // 
            this.txtFeedback.Location = new System.Drawing.Point(666, 44);
            this.txtFeedback.Multiline = true;
            this.txtFeedback.Name = "txtFeedback";
            this.txtFeedback.ReadOnly = true;
            this.txtFeedback.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtFeedback.Size = new System.Drawing.Size(246, 188);
            this.txtFeedback.TabIndex = 5;
            this.txtFeedback.TextChanged += new System.EventHandler(this.txtFeedback_TextChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(666, 240);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(246, 30);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit Assignment / Blog";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(666, 292);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(120, 30);
            this.btnRefresh.TabIndex = 7;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(792, 292);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(120, 30);
            this.btnLogout.TabIndex = 8;
            this.btnLogout.Text = "Log out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // StudentDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 451);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtFeedback);
            this.Controls.Add(this.txtPosts);
            this.Controls.Add(this.tabDetails);
            this.Controls.Add(this.listAwards);
            this.Controls.Add(this.listCompetitions);
            this.Controls.Add(this.lblWelcome);
            this.Name = "StudentDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Mode";
            this.tabDetails.ResumeLayout(false);
            this.tabDetail.ResumeLayout(false);
            this.tabDetail.PerformLayout();
            this.tabLeaderboard.ResumeLayout(false);
            this.tabLeaderboard.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
