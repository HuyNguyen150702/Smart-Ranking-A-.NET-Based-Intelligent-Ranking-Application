﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace dotnet_assignment2 {
    public static class FileManager {
        public static void SaveEntity<T>(T entity, string filePath) {
            string json = JsonSerializer.Serialize(entity);
            File.AppendAllText(filePath, json + Environment.NewLine);
        }

        // if no filePath is defined then it is auto admin mode (overloading)
        public static void SaveEntity<T>(T entity) {
            string json = JsonSerializer.Serialize(entity);
            File.AppendAllText(Utils.ADMIN, json + Environment.NewLine);
        }

        public static List<T> LoadEntities<T>(string filePath) {
            List<T> entities = new List<T>();

            if (!File.Exists(filePath))
                return entities;

            foreach (string line in File.ReadLines(filePath)) {
                if (!string.IsNullOrWhiteSpace(line)) {
                    try {
                        var entity = JsonSerializer.Deserialize<T>(line);
                        if (entity != null)
                            entities.Add(entity);
                    } catch (JsonException exception) {
                        Console.WriteLine($"Warning: Skipping malformed line in file. Exception: {exception}");
                    }
                }
            }

            return entities;
        }

        /**
         * Create a database files if not exists, also create a default admin account for creating doctor
         * and patients
         */
        public static void EnsureDataDirectoryAndFiles() {
            string dataDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");
            bool dataDirExisted = Directory.Exists(dataDir);

            Directory.CreateDirectory(dataDir); // Creates if not exists, does nothing if exists

            string[] files = { "id_list.txt", "admin.txt", "student.txt",  "teacher.txt" };

            foreach (var file in files) {
                string filePath = Path.Combine(dataDir, file);
                if (!File.Exists(filePath)) {
                    // Create an empty file
                    File.Create(filePath).Dispose(); // Dispose to release the file handle immediately
                }
            }

            // Only create and save the admin if the data directory did NOT exist before
            if (!dataDirExisted) {
                Admin admin = new Admin
                (
                    10000, // only default admin has this id
                    "admin",
                    "Phuc Minh Son",
                    "Nguyen",
                    "phucminhson.nguyen@student.uts.edu.au",
                    "1234567890",
                    "Sydney"
                );

                SaveEntity(admin);

                Console.WriteLine($"Created a super admin in {Utils.ADMIN}");
            }
        }
    }
}
