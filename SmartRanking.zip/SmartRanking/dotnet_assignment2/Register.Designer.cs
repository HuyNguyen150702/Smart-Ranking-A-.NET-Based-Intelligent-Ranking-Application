﻿using System.Drawing;
using System.Windows.Forms;

namespace dotnet_assignment2
{
    partial class Register
    {
        private System.ComponentModel.IContainer components = null;

        // Designer fields
        private TextBox TxtUsername;
        private TextBox TxtPassword;
        private TextBox TxtConfirmed;
        private Label labelTitle;
        private Label labelUser;
        private Label labelPass;
        private Label labelConfirm;
        private CheckBox checkBox1;
        private Button button1; // REGISTER
        private Button button2; // CLEAR
        private Label labelHaveAcc;
        private Label label6;   // Back To Log In

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.TxtUsername = new TextBox();
            this.TxtPassword = new TextBox();
            this.TxtConfirmed = new TextBox();
            this.labelTitle = new Label();
            this.labelUser = new Label();
            this.labelPass = new Label();
            this.labelConfirm = new Label();
            this.checkBox1 = new CheckBox();
            this.button1 = new Button();
            this.button2 = new Button();
            this.labelHaveAcc = new Label();
            this.label6 = new Label();
            this.SuspendLayout();
            // 
            // Form
            // 
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.White;
            this.ClientSize = new Size(560, 420);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.Name = "Form3";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Register";
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.labelTitle.ForeColor = Color.DodgerBlue;
            this.labelTitle.Location = new Point(187, 24);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new Size(183, 30);
            this.labelTitle.Text = "Let's Get Started";
            this.labelTitle.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.Location = new Point(88, 92);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new Size(63, 15);
            this.labelUser.Text = "Username:";
            // 
            // TxtUsername
            // 
            this.TxtUsername.BorderStyle = BorderStyle.FixedSingle;
            this.TxtUsername.Font = new Font("Segoe UI", 10F);
            this.TxtUsername.ForeColor = Color.FromArgb(0, 117, 214);
            this.TxtUsername.Location = new Point(88, 110);
            this.TxtUsername.Name = "TxtUsername";
            this.TxtUsername.Size = new Size(380, 25);
            // 
            // labelPass
            // 
            this.labelPass.AutoSize = true;
            this.labelPass.Location = new Point(88, 152);
            this.labelPass.Name = "labelPass";
            this.labelPass.Size = new Size(60, 15);
            this.labelPass.Text = "Password:";
            // 
            // TxtPassword
            // 
            this.TxtPassword.BorderStyle = BorderStyle.FixedSingle;
            this.TxtPassword.Font = new Font("Segoe UI", 10F);
            this.TxtPassword.ForeColor = Color.FromArgb(0, 117, 214);
            this.TxtPassword.Location = new Point(88, 170);
            this.TxtPassword.Name = "TxtPassword";
            this.TxtPassword.Size = new Size(380, 25);
            this.TxtPassword.Multiline = false;                // important
            this.TxtPassword.UseSystemPasswordChar = true;     // important
            // 
            // labelConfirm
            // 
            this.labelConfirm.AutoSize = true;
            this.labelConfirm.Location = new Point(88, 212);
            this.labelConfirm.Name = "labelConfirm";
            this.labelConfirm.Size = new Size(121, 15);
            this.labelConfirm.Text = "Confirmed Password:";
            this.labelConfirm.Click += new System.EventHandler(this.label4_Click);
            // 
            // TxtConfirmed
            // 
            this.TxtConfirmed.BorderStyle = BorderStyle.FixedSingle;
            this.TxtConfirmed.Font = new Font("Segoe UI", 10F);
            this.TxtConfirmed.ForeColor = Color.FromArgb(0, 117, 214);
            this.TxtConfirmed.Location = new Point(88, 230);
            this.TxtConfirmed.Name = "TxtConfirmed";
            this.TxtConfirmed.Size = new Size(380, 25);
            this.TxtConfirmed.Multiline = false;               // important
            this.TxtConfirmed.UseSystemPasswordChar = true;    // important
            this.TxtConfirmed.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // checkBox1 (Show Password)
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new Point(348, 261);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new Size(120, 19);
            this.checkBox1.Text = "Show Passwords";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button1 (REGISTER)
            // 
            this.button1.BackColor = Color.DodgerBlue;
            this.button1.FlatStyle = FlatStyle.Flat;
            this.button1.ForeColor = Color.White;
            this.button1.Location = new Point(88, 297);
            this.button1.Name = "button1";
            this.button1.Size = new Size(184, 38);
            this.button1.Text = "REGISTER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2 (CLEAR)
            // 
            this.button2.BackColor = Color.DodgerBlue;
            this.button2.FlatStyle = FlatStyle.Flat;
            this.button2.ForeColor = Color.White;
            this.button2.Location = new Point(284, 297);
            this.button2.Name = "button2";
            this.button2.Size = new Size(184, 38);
            this.button2.Text = "CLEAR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // labelHaveAcc
            // 
            this.labelHaveAcc.AutoSize = true;
            this.labelHaveAcc.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.labelHaveAcc.ForeColor = Color.Black;
            this.labelHaveAcc.Location = new Point(192, 350);
            this.labelHaveAcc.Name = "labelHaveAcc";
            this.labelHaveAcc.Size = new Size(177, 19);
            this.labelHaveAcc.Text = "Already Have An Account?";
            // 
            // label6 (Back To Log In)
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.label6.ForeColor = Color.DodgerBlue;
            this.label6.Location = new Point(230, 372);
            this.label6.Name = "label6";
            this.label6.Size = new Size(107, 19);
            this.label6.Text = "Back To Log In";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Add controls
            // 
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.labelUser);
            this.Controls.Add(this.TxtUsername);
            this.Controls.Add(this.labelPass);
            this.Controls.Add(this.TxtPassword);
            this.Controls.Add(this.labelConfirm);
            this.Controls.Add(this.TxtConfirmed);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.labelHaveAcc);
            this.Controls.Add(this.label6);

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
