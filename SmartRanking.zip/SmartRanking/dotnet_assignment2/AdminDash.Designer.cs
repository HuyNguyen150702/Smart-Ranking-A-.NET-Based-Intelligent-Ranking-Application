﻿namespace dotnet_assignment2
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            labelTitle = new Label();
            btnManageUsers = new Button();
            btnManageAwards = new Button();
            btnManageCompetitions = new Button();
            btnPosts = new Button();
            btnSystem = new Button();
            btnAwardsLeaderboard = new Button();
            btnLogout = new Button();
            SuspendLayout();
            // 
            // labelTitle
            // 
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            labelTitle.Location = new Point(280, 26);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(200, 30);
            labelTitle.TabIndex = 0;
            labelTitle.Text = "Admin Dashboard";
            // 
            // btnManageUsers
            // 
            btnManageUsers.Location = new Point(280, 80);
            btnManageUsers.Name = "btnManageUsers";
            btnManageUsers.Size = new Size(200, 40);
            btnManageUsers.TabIndex = 1;
            btnManageUsers.Text = "Manage Users";
            btnManageUsers.UseVisualStyleBackColor = true;
            btnManageUsers.Click += btnManageUsers_Click;
            // 
            // btnManageAwards
            // 
            btnManageAwards.Location = new Point(280, 130);
            btnManageAwards.Name = "btnManageAwards";
            btnManageAwards.Size = new Size(200, 40);
            btnManageAwards.TabIndex = 2;
            btnManageAwards.Text = "Manage Awards";
            btnManageAwards.UseVisualStyleBackColor = true;
            btnManageAwards.Click += btnManageAwards_Click;
            // 
            // btnManageCompetitions
            // 
            btnManageCompetitions.Location = new Point(280, 180);
            btnManageCompetitions.Name = "btnManageCompetitions";
            btnManageCompetitions.Size = new Size(200, 40);
            btnManageCompetitions.TabIndex = 3;
            btnManageCompetitions.Text = "Manage Competitions";
            btnManageCompetitions.UseVisualStyleBackColor = true;
            btnManageCompetitions.Click += btnManageCompetitions_Click;
            // 
            // btnPosts
            // 
            btnPosts.Location = new Point(280, 230);
            btnPosts.Name = "btnPosts";
            btnPosts.Size = new Size(200, 40);
            btnPosts.TabIndex = 4;
            btnPosts.Text = "Post Management";
            btnPosts.UseVisualStyleBackColor = true;
            btnPosts.Click += btnPosts_Click;
            // 
            // btnSystem
            // 
            btnSystem.Location = new Point(280, 280);
            btnSystem.Name = "btnSystem";
            btnSystem.Size = new Size(200, 40);
            btnSystem.TabIndex = 5;
            btnSystem.Text = "System Monitoring";
            btnSystem.UseVisualStyleBackColor = true;
            btnSystem.Click += btnSystem_Click;
            // 
            // btnAwardsLeaderboard
            // 
            btnAwardsLeaderboard.Location = new Point(280, 330);
            btnAwardsLeaderboard.Name = "btnAwardsLeaderboard";
            btnAwardsLeaderboard.Size = new Size(200, 40);
            btnAwardsLeaderboard.TabIndex = 6;
            btnAwardsLeaderboard.Text = "Awards & Leaderboard Oversight";
            btnAwardsLeaderboard.UseVisualStyleBackColor = true;
            btnAwardsLeaderboard.Click += btnAwardsLeaderboard_Click;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Firebrick;
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(280, 400);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(200, 40);
            btnLogout.TabIndex = 7;
            btnLogout.Text = "Log Out";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // Form5
            // 
            ClientSize = new Size(800, 480);
            Controls.Add(btnLogout);
            Controls.Add(btnAwardsLeaderboard);
            Controls.Add(btnSystem);
            Controls.Add(btnPosts);
            Controls.Add(btnManageCompetitions);
            Controls.Add(btnManageAwards);
            Controls.Add(btnManageUsers);
            Controls.Add(labelTitle);
            Name = "Form5";
            Text = "Admin Dashboard";
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Button btnManageUsers;
        private System.Windows.Forms.Button btnManageAwards;
        private System.Windows.Forms.Button btnManageCompetitions;
        private System.Windows.Forms.Button btnPosts;
        private System.Windows.Forms.Button btnSystem;
        private System.Windows.Forms.Button btnAwardsLeaderboard;
        private System.Windows.Forms.Button btnLogout;
    }
}
